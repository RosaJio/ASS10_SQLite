package com.mobi.ass10_sqlite

class Student (val id:String, val name:String, val age:Int) {
}